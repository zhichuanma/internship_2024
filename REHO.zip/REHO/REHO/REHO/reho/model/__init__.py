__doc__ = """
*Directory for model-related code.*
"""
__doc__ = """
*The folder containing plotting functions, and code relative to the visualization of REHO results.*
"""
